/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrtask7;
import java.util.Arrays;
import java.util.Scanner;
public class Arrtask7 {
    public static void main(String[] args){
      Scanner scan=new Scanner (System.in);  
      String str1=scan.nextLine();
      String str2=scan.nextLine();
      str1=str1.toLowerCase();
      str2=str2.toLowerCase();
    if(str1.length()==str2.length()){
        char[] a=str1.toCharArray();
        char[] b=str1.toCharArray(); 
        Arrays.sort(a);
        Arrays.sort(b);
        boolean flag=Arrays.equals(a,b);
if(flag){
    System.out.println("anagram");}
else{
    System.out.println("not anagram");}}
    else{
        System.out.println("Strings are not angram");}}}
    

