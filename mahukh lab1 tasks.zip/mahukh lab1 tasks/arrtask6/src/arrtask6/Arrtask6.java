/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrtask6;
import java.util.Scanner;
public class Arrtask6 {
    public static void main(String[] args){
        Scanner scan=new Scanner (System.in);  
        String str=scan.nextLine();
        String rev="";
        for(int i=str.length()-1;i>=0;i--){
            rev=rev+str.charAt(i);
        }
    if(str.toLowerCase().equals(rev.toLowerCase())){
        System.out.println("palindrome");}
    else{
        System.out.println("not palindrome");}}
}
