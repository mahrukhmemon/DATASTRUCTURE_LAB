/*;i<arr
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arr2;
import java.util.Scanner;
public class Arraytask1{
    public static void main(String[] args){
        int arr[]={5, 15, 25, 35, 45,55};
        for(int i=0;i<arr.length;i++){
            System.out.println("element at each index "+i+":"+arr[i]+" ");}
    }}