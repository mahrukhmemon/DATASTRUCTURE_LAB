/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrtask4;
public class Arrtask4{
    public static void main(String[] args){
        int index1=4;
        int arr1[]={13,26,39,52,65};
        int element=arr1[index1];
        System.out.println("element found at index "+index1+":"+element);
        int arr2[]={2,4,6,8,10};
        int index2=3;
        int element2=arr2[index2];
        System.out.println("element 8 found at :"+index2);
        int arr3[]={11,22,33,44,55};
        int index3=2;
        int element3=arr3[index3];
        System.out.println("element 33 found at :"+index3);}}
