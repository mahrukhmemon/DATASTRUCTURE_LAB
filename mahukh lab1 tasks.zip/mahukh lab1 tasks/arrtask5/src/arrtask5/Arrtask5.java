/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrtask5;
public class Arrtask5 {
    public static void main(String[] args) {
  int arr[]={1,3,5,7,9};
        int[] temp=new int[arr.length];
   System.out.println("before reversal");
   for(int i=0;i<arr.length;i++){
      System.out.print(arr[i]+" ");}
        System.out.println();
    System.out.println("after reversal");
  for(int i=0;i<arr.length;i++){
temp[i]=arr[arr.length-1-i]; 
  }
for(int i=0;i<arr.length;i++){
arr[i]=temp[i]; }
   for(int i=0;i<arr.length;i++){
      System.out.print(arr[i]+" ");}
    }}
