/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrtk2;
public class Arrtk2 {
    public static void main(String[] args) {
        int arr[]=new int[6];
        arr[0]=12;
        arr[1]=24;
        arr[2]=36;
        arr[3]=48;
        arr[4]=60;
         System.out.println("before inserting");
         for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");}
        for(int i=arr.length-1;i>0;i--){
            arr[i]=arr[i-1];}
        System.out.println();
        arr[0]=6;
        System.out.println("after inserting");
         for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");}
         System.out.println();
        arr[0]=100;
        arr[1]=200;
        arr[2]=300;
        arr[3]=400;
        arr[4]=500;
         System.out.println("before inserting in middle");
         for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");}
         System.out.println();
         for(int i=arr.length-1;i>2;i--){
            arr[i]=arr[i-1];}
         arr[2]=250;
        System.out.println("after inserting in middle");
          for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");}
          System.out.println();
         arr[0]=3;
        arr[1]=6;
        arr[2]=9;
        arr[3]=12;
        arr[4]=15; 
        System.out.println("before inserting at last");
         for(int i=0;i<arr.length-1;i++){
            System.out.print(arr[i]+" ");}
         System.out.println();
           arr[5]=18; 
           System.out.println("after inserting at last");
           for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");}   
    }
    
}
